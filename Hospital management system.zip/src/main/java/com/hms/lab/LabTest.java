package com.hms.lab;

public class LabTest {
    private int testId;
    private int patientId;
    private String testName;
    private String testDate;
    private String result;

    public int getTestId() { return testId; }
    public void setTestId(int testId) { this.testId = testId; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getTestName() { return testName; }
    public void setTestName(String testName) { this.testName = testName; }

    public String getTestDate() { return testDate; }
    public void setTestDate(String testDate) { this.testDate = testDate; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
}
